--DROP TABLE IF EXISTS students;


CREATE TABLE "public"."booklist" 
(
  booklist_id SERIAL PRIMARY KEY,
  title TEXT, 
  author TEXT, 
  publisher TEXT, 
  published_date TEXT, 
  identifier TEXT, 
  identifier_type TEXT, 
  user_id INT NOT NULL, 
  imagelink TEXT,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status TEXT,
  favorite TEXT
);

CREATE TABLE log_in (
  user_id SERIAL PRIMARY KEY,
  firstname TEXT NOT NULL,
  lastname TEXT NOT NULL,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  last_login TIMESTAMP NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bt_search_log (
  search_id SERIAL PRIMARY KEY,
  url TEXT NOT NULL,
  user_id INT NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);