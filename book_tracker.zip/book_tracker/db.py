# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 14:12:04 2020

@author: kbootsri
"""

import psycopg2

from flask import g


def get_db():
    
    
    connection = psycopg2.connect(user = "zowglzqx",
                                  password = "HinwKUQSD2t_10zuQK5Tln-us-7N9JsI",
                                  host = "drona.db.elephantsql.com",
                                  database = "zowglzqx")
    
    cursor = connection.cursor()
    
    return cursor

def get_conn():
    
    connection = psycopg2.connect(user = "zowglzqx",
                                  password = "HinwKUQSD2t_10zuQK5Tln-us-7N9JsI",
                                  host = "drona.db.elephantsql.com",
                                  database = "zowglzqx")

    return connection


def close_db(e=None):
    db = g.pop('db', None)

    if db is not None:
        db.close()

def close_cxn():        
    connection = psycopg2.connect(user = "zowglzqx",
                                  password = "HinwKUQSD2t_10zuQK5Tln-us-7N9JsI",
                                  host = "drona.db.elephantsql.com",
                                  database = "zowglzqx")
    
    cursor = connection.cursor()
    
    
    
    
    csr = connection.cursor()  
    csr.close()