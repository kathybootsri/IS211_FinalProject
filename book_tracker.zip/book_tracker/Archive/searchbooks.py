# -*- coding: utf-8 -*-
"""
Created on Mon Apr 13 12:33:22 2020

@author: kathy
"""

from flask import (Blueprint, flash, g, redirect, render_template, request, url_for)
from werkzeug.exceptions import abort

from book_tracker.auth import login_required
from book_tracker.db import (get_db, get_conn)
import requests
import pandas as pd
import json

bp = Blueprint('search', __name__, url_prefix='/search')

@bp.route('/', methods=('GET', 'POST'))

def search_book():
    if request.method == 'POST':
        keywords = request.form['keywords']
        intitle = request.form['intitle']
#        inauthor = request.form['inauthor']
#        isbn = request.form['isbn']
#        subject = request.form['subject']    
        error = None
    
    #TEST WORD ENTRIES
    #keywords = 'pride prejudice'
    #intitle = 'austen'
    #inauthor = 'austen'
    #isbn = None
    #subject = None   
    #error = None
            
    #Actual Working Sample: https://www.googleapis.com/books/v1/volumes?q=pride+prejudice+inauthor:austen&maxResults=1&key=AIzaSyBNI2AhmCAfCDxlt-C-m7GVAamTtmLry8k
    
        start_url = 'https://www.googleapis.com/books/v1/volumes?q='
        end_url = '&maxResults=1&key=AIzaSyBNI2AhmCAfCDxlt-C-m7GVAamTtmLry8k'
        
        fields = {keywords: '', intitle: 'intitle:'}#, inauthor: 'inauthor:', isbn: 'isbn:', subject: 'subject:'}
        
        search_results = ''
        
        for key, value in fields.items():
            if key is not None:
                new_keywords = key.split()
                first_word = '%s'.join(new_keywords) % (value)
                format_keywords = first_word + '+'
                search_results += format_keywords
        
        search_string = search_results.rstrip('+')
        
        URL = start_url + search_string + end_url

        return URL

    return render_template('search/search.html')
    


@bp.route('/result')
def retrieve_result():
    URL = search_book()

    df = pd.read_json(URL, orient = 'record')
    
    
    df.drop(columns = ['kind', 'id', 'etag', 'selfLink'], inplace = True)
    df.reset_index(inplace = True)
    
    title = df['volumeInfo'].iat[0]
    subtitle = df['volumeInfo'].iat[1]
    author = df['volumeInfo'].iat[2]
    publisher = df['volumeInfo'].iat[3]
    published_date = df['volumeInfo'].iat[4]
    description = df['volumeInfo'].iat[5]
    first_isbn = df['volumeInfo'].iat[6][0]
    second_isbn = df['volumeInfo'].iat[6][1]
    for key, value in first_isbn.items():
        if key == 'identifier':
            isbn10 = value
    
    for key, value in second_isbn.items():
        if key == 'identifier':
            isbn13 = value
            
    categories = df['volumeInfo'].iat[12]
    
    image = df['volumeInfo'].iat[19]
    
    for key, value in image.items():
        if key == 'smallThumbnail':
            imagelink = value
        
    previewlink = df['volumeInfo'].iat[21]
  
    return render_template('search/results.html')    


@bp.route('/result/add', methods=('GET', 'POST'))
def addbook():
    URL = search_book()

    df = pd.read_json(URL, orient = 'record')
    
    
    df.drop(columns = ['kind', 'id', 'etag', 'selfLink'], inplace = True)
    df.reset_index(inplace = True)
    
    title = df['volumeInfo'].iat[0]
    subtitle = df['volumeInfo'].iat[1]
    author = df['volumeInfo'].iat[2]
    publisher = df['volumeInfo'].iat[3]
    published_date = df['volumeInfo'].iat[4]
    description = df['volumeInfo'].iat[5]
    first_isbn = df['volumeInfo'].iat[6][0]
    second_isbn = df['volumeInfo'].iat[6][1]
    for key, value in first_isbn.items():
        if key == 'identifier':
            isbn10 = value
    
    for key, value in second_isbn.items():
        if key == 'identifier':
            isbn13 = value
            
    categories = df['volumeInfo'].iat[12]
    
    image = df['volumeInfo'].iat[19]
    
    for key, value in image.items():
        if key == 'smallThumbnail':
            imagelink = value
        
    previewlink = df['volumeInfo'].iat[21]

    connection = get_conn()
    cursor = connection.cursor()    
    cursor.execute(
        'INSERT INTO "public"."booklist" (title, author, published_date, isbn10, isbn13, user_id, imagelink) VALUES (%s, %s, %s, %s, %s, %s, %s)', (title, author, published_date, isbn10, isbn13, g.user[0], imagelink))
    connection.commit()
        
    return redirect(url_for('dashboard.index'))        

