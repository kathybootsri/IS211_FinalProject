# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 16:39:41 2019

@author: kbootsri
"""

from flask import Flask


def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(SECRET_KEY='dev')
    app.jinja_env.auto_reload = True
    app.config['TEMPLATES_AUTO_RELOAD'] = True
        
    if test_config is None:
        app.config.from_pyfile('config.py', silent=True)
    else:
        app.config.from_mapping(test_config)

    # a simple page that says hello

    from . import auth
    app.register_blueprint(auth.bp)

    from . import searchbooks
    app.register_blueprint(searchbooks.bp)
    
    from . import dashboard
    app.register_blueprint(dashboard.bp)


    
    return app

if __name__ == '__main__':
    app.run()