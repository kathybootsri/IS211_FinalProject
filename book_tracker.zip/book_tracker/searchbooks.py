# -*- coding: utf-8 -*-
"""
Created on Mon Apr 13 12:33:22 2020

@author: kathy
"""

from flask import (Blueprint, g, flash, redirect, render_template, request, url_for)
from werkzeug.exceptions import abort
from book_tracker.auth import login_required
from book_tracker.db import (get_db, get_conn,close_cxn)
import pandas as pd
import json
import urllib.request

bp = Blueprint('search', __name__, url_prefix='/search')



@bp.route('/', methods=('GET', 'POST'))
def search_book():
    error = None
    if request.method == 'POST':
        keywords = request.form['keywords']
        isbn = request.form['isbn']
        error = None

        if not keywords and not isbn:
            error = 'Search by either keywords or ISBN.'

        if error is not None:
            flash(error)
            
        start_url = 'https://www.googleapis.com/books/v1/volumes?q='
        end_url = '&maxResults=1&key=AIzaSyBNI2AhmCAfCDxlt-C-m7GVAamTtmLry8k'
    
    #    def create_url():
        if keywords and not isbn:
            fields = {keywords: ''}
            
            search_results = ''
            
            for key, value in fields.items():
                if key is not None:
                    new_keywords = key.split()
                    first_word = value.join(new_keywords) 
                    format_keywords = first_word + '+'
                    search_results += format_keywords
            
            search_string = search_results.rstrip('+')
            
            URL = start_url + search_string + end_url
            
        if isbn and not keywords: 
            fields = {isbn: 'isbns:'}
            start_url = 'https://www.googleapis.com/books/v1/volumes?q='
            end_url = '&maxResults=1&key=AIzaSyBNI2AhmCAfCDxlt-C-m7GVAamTtmLry8k'
                    
            search_results = ''
            
            for key, value in fields.items():
                new_keywords =  '+' + value + key + '+'
            
            search_results += new_keywords
            
            search_string = search_results.rstrip('+')
            URL = start_url + search_string + end_url            

        with urllib.request.urlopen(URL) as url:   
            data = json.loads(url.read().decode())
        
        search_results = data['totalItems']
        
        if search_results != 0:
        
            connection = get_conn()
            cursor = connection.cursor()    
            cursor.execute(
                'INSERT INTO "public"."bt_search_log" (url, user_id) VALUES (%s, %s)', (URL, g.user[0]))
            connection.commit()
            
        else:   
            connection = get_conn()
            cursor = connection.cursor()    
            cursor.execute(
                'INSERT INTO "public"."bt_search_log" (url, user_id) VALUES (%s, %s)', (URL, g.user[0]))
            connection.commit()
            error = 'No book found.'
            flash(error)            
            return redirect(url_for('search.search_book')) 
        
        return redirect(url_for('search.retrieve_result')) 
    return render_template('search/search.html', error = error)   
        
    
@bp.route('/result')
def retrieve_result():
    db = get_db()
    db.execute('SELECT * FROM "public"."bt_search_log" WHERE user_id = %s ORDER BY created DESC', (g.user[0],))

        
    data = db.fetchone()
    close_cxn()
    URL = data[1]
    user = data[2]

    with urllib.request.urlopen(URL) as url:   
        data = json.loads(url.read().decode())
    
    df = pd.DataFrame(data['items'][0])
    
    df.drop(columns = ['kind', 'id', 'etag', 'selfLink'], inplace = True)
    
    title = df.loc['title', 'volumeInfo']
    list = df.loc['authors', 'volumeInfo']
    nobody = ''
    for x in list:
        nobody += ', '
        nobody += x
        
    author = nobody[2:]
    
    try:
        publisher = df.loc['publisher', 'volumeInfo']
    except:    
        publisher = 'N/A' 
    else:
        publisher = df.loc['publisher', 'volumeInfo']
    try:
        published_date = df.loc['publishedDate', 'volumeInfo']
    except:    
        published_date = 'N/A' 
    try:
        industry_id = df.loc['industryIdentifiers', 'volumeInfo'][0]
    except:    
        industry_id = 'N/A'     
    try:
        buy_link = df.loc['buyLink', 'saleInfo']
    except:    
        buy_link = None        
    try:
        imagelinks = df.loc['imageLinks', 'volumeInfo']['thumbnail'] 
    except:    
        imagelinks = None  
    try:
        isbns = industry_id.items()
    except: 
        isbns = None
  
    return render_template('search/results.html', title = title, author = author, publisher = publisher, published_date = published_date, buy_link = buy_link, imagelinks = imagelinks, user = user, isbns = isbns)    


@bp.route('/result/add', methods=('GET', 'POST'))
@login_required
def addbook():
    db = get_db()
    db.execute('SELECT * FROM "public"."bt_search_log" WHERE user_id = %s ORDER BY created DESC', (g.user[0],))
    data = db.fetchone()
    URL = data[1]
    user = data[2]

    with urllib.request.urlopen(URL) as url:   
        data = json.loads(url.read().decode())
    
    df = pd.DataFrame(data['items'][0])
    
    df.drop(columns = ['kind', 'id', 'etag', 'selfLink'], inplace = True)

    
    title = df.loc['title', 'volumeInfo']
    list = df.loc['authors', 'volumeInfo']
    nobody = ''
    for x in list:
        nobody += ', '
        nobody += x
        
    author = nobody[2:]
    
    try:
        publisher = df.loc['publisher', 'volumeInfo']
    except:    
        publisher = 'N/A' 
    else:
        publisher = df.loc['publisher', 'volumeInfo']
    try:
        published_date = df.loc['publishedDate', 'volumeInfo']
    except:    
        published_date = 'N/A' 
    try:
        industry_id = df.loc['industryIdentifiers', 'volumeInfo'][0]
    except:    
        industry_id = 'N/A'     
    try:
        buy_link = df.loc['buyLink', 'saleInfo']
    except:    
        buy_link = None             
    try:
        imagelinks = df.loc['imageLinks', 'volumeInfo']['thumbnail'] 
    except:    
        imagelinks = None  
    try:
        isbns = industry_id.items()
    except: 
        isbns = None
    if isbns:
        for key, value in isbns:
            key = key
            value = value
    else:
        key = None
        value = None

    db.execute('SELECT * FROM "public"."booklist" WHERE title = %s AND author = %s and publisher = %s and published_date = %s', (title, author, publisher, published_date))
    check_dup = db.fetchone()
    
    connection = get_conn()
    cursor = connection.cursor()    
    if check_dup is None:
        cursor.execute(
            'INSERT INTO "public"."booklist" (title, author, publisher, published_date, identifier, identifier_type, user_id, imagelink, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)', (title, author, publisher, published_date, value, key, g.user[0], imagelinks, 'Not Read'))
        connection.commit()
    else:
        abort(404, "Book already on booklist doesn't exist.")
        
    return redirect(url_for('dashboard.index_notread'))        

