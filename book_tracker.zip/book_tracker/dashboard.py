# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 15:04:49 2020

@author: kbootsri
"""

from flask import (g, Blueprint, render_template, redirect, url_for)
from werkzeug.exceptions import abort
from book_tracker.db import (get_db, get_conn)
from book_tracker.auth import login_required

bp = Blueprint('dashboard', __name__)

def get_post(id, check_author=True):
    db = get_db()
    db.execute('SELECT * FROM "public"."booklist" WHERE booklist_id = %s and user_id = %s' % (id, g.user[0]))
    post = db.fetchone()
    if post is None:
        abort(404, "Booklist id {0} doesn't exist.".format(id))

    if check_author and int(post[7]) != g.user[0]:
        abort(403)
    else:
        return post


@bp.route('/')
def index_notread():
    if g.user is not None:
        db = get_db()
        db.execute('SELECT * FROM "public"."booklist" WHERE status = \'Not Read\' and user_id = %s' % (g.user[0],))
        booklist_unread = db.fetchall()
        
        return render_template('dashboard/index_notread.html', booklist_unread=booklist_unread)
    
    else:
        return redirect(url_for('auth.login'))

@bp.route('/read')
def index_read():
    if g.user is not None:
        db = get_db()


        db.execute('SELECT * FROM "public"."booklist" WHERE status = \'Read\' and user_id = %s' % (g.user[0],))
        booklist_read = db.fetchall()
        
        return render_template('dashboard/index_read.html', booklist_read = booklist_read)
    
    else:
        return redirect(url_for('auth.login'))

@bp.route('/favorite')
def index_favorite():
    if g.user is not None:
        db = get_db()

        db.execute('SELECT * FROM "public"."booklist" WHERE favorite = \'Favorite\' and user_id = %s' % (g.user[0],))
        favorite_list = db.fetchall()
        
        return render_template('dashboard/index_favorite.html', favorite_list = favorite_list)
    
    else:
        return redirect(url_for('auth.login'))
    
@bp.route('/<int:id>/read', methods=('GET', 'POST'))
@login_required
def read(id):

    db = get_db()
    db.execute('SELECT status FROM "public"."booklist" WHERE booklist_id = %s' % (id,))
    read_status = db.fetchone()
    
    db = get_db()
    connection = get_conn()
    cursor = connection.cursor() 
    if read_status[0] == 'Not Read':
        read_script = 'UPDATE "public"."booklist" SET status = \'Read\' WHERE booklist_id = %s and user_id = %s' % (id, g.user[0])
        
    else:
        read_script = 'UPDATE "public"."booklist" SET status = \'Not Read\' WHERE booklist_id = %s and user_id = %s' % (id, g.user[0])
        
    cursor.execute(read_script)
    connection.commit()
    cursor.close()
    return redirect(url_for('dashboard.index_read'))   

@bp.route('/<int:id>/favorite', methods=('GET', 'POST'))
@login_required
def favorite(id):

    db = get_db()
    db.execute('SELECT favorite FROM "public"."booklist" WHERE booklist_id = %s' % (id,))
    favorite_status = db.fetchone()    

    connection = get_conn()
    cursor = connection.cursor() 
    if favorite_status[0] == 'Favorite':
        fav_script = 'UPDATE "public"."booklist" SET favorite = NULL WHERE booklist_id = %s and user_id = %s' % (id, g.user[0])
    else:
        fav_script = 'UPDATE "public"."booklist" SET favorite = \'Favorite\' WHERE booklist_id = %s and user_id = %s' % (id, g.user[0])
    cursor.execute(fav_script)
    connection.commit()
    cursor.close()
    return redirect(url_for('dashboard.index_favorite'))  


@bp.route('/<int:id>/delete', methods=('GET', 'POST'))
@login_required
def delete(id):

    print('DELETE FROM "public"."booklist" WHERE booklist_id = %s and user_id = %s' % (id, g.user[0]))
    connection = get_conn()
    cursor = connection.cursor() 
    cursor.execute('DELETE FROM "public"."booklist" WHERE booklist_id = %s and user_id = %s' % (id, g.user[0]))
    connection.commit()
    cursor.close()
    return redirect(url_for('dashboard.index_notread'))   

@bp.route('/deleteall', methods=('GET', 'POST'))
@login_required
def deleteall():
    connection = get_conn()
    cursor = connection.cursor() 
    cursor.execute('DELETE FROM "public"."booklist"')
    connection.commit()
    cursor.close()
    return redirect(url_for('search.search_book'))   